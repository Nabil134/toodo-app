import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';

class calculator extends StatefulWidget {
  @override
  _calculatorState createState() => _calculatorState();
}

class _calculatorState extends State<calculator> {
  var result = '';
  Widget btn(var txt) {
    return ElevatedButton(
      child: Text(txt),
      onPressed: () {
        setState(() {
          result = result + txt;
        });
      },
      style: ElevatedButton.styleFrom(primary: Colors.blue, padding: EdgeInsets.fromLTRB(0, 10, 0, 0), textStyle: TextStyle(fontWeight: FontWeight.bold)),
    );
  }

  clear() {
    setState(() {
      result = "";
    });
  }

  output() {
    Parser p = Parser();
    Expression exp = p.parse(result);
    ContextModel cm = ContextModel();
    double evl = exp.evaluate(EvaluationType.REAL, cm);
    setState(() {
      result = evl.toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, //Removing Debug Banner
      home: Scaffold(
        body: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            result,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            btn('1'),
            btn('2'),
            btn('3'),
            btn('4'),
          ]), //Row1
          SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            btn('5'),
            btn('6'),
            btn('7'),
            btn('8'),
          ]), //Row2
          SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            btn('9'),
            btn('0'),
            btn('+'),
            btn('-'),
          ]), //Row3
          SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            btn('*'),
            btn('/'),
            ElevatedButton(
              child: Text('Clear'),
              onPressed: () {
                clear();
              },
            ),
            ElevatedButton(
              child: Text('='),
              onPressed: () {
                output();
              },
            ),
          ]), //Row4
        ]),
      ),
    );
  }
}
